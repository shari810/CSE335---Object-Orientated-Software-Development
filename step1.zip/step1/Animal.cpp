/**
 * @file Animal.cpp
 * @author nicholas shari
 */

#include "Animal.h"

/**
 * Destructor
 */
Animal::~Animal()
{
}

