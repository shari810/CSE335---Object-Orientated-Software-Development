var class_cow =
[
    [ "Type", "class_cow.html#a8c4921713b515e2723a80bdc7cfb6a88", [
      [ "Bull", "class_cow.html#a8c4921713b515e2723a80bdc7cfb6a88a92c21511d7b383b2f8ba5b00c3c9a473", null ],
      [ "BeefCow", "class_cow.html#a8c4921713b515e2723a80bdc7cfb6a88a45d1e7575b49152ad2b30c12df8a5f50", null ],
      [ "MilkCow", "class_cow.html#a8c4921713b515e2723a80bdc7cfb6a88a90d3a3cd67e9a151f1875d7e958efffb", null ]
    ] ],
    [ "DisplayAnimal", "class_cow.html#a7d36fe68f1ca42508056d61e9e4c3990", null ],
    [ "IsFemale", "class_cow.html#af2b347706004311cb6b763e5868d7384", null ],
    [ "ObtainCowInformation", "class_cow.html#af62471383d151fd32ca07cd4033838c2", null ],
    [ "mMilkProduction", "class_cow.html#a1606490c9f72d3ae1b755f8d69d795c5", null ],
    [ "mName", "class_cow.html#a287e1e100db89826d883d5391e1dfc01", null ],
    [ "mType", "class_cow.html#a62e62f2822bedf042a49795e9c38cf4b", null ]
];