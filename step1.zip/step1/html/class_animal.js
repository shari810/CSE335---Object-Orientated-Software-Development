var class_animal =
[
    [ "~Animal", "class_animal.html#a476af25adde5f0dfa688129c8f86fa5c", null ],
    [ "DisplayAnimal", "class_animal.html#a0e7119b37803fe4e46562cb9791f501b", null ],
    [ "IsFemale", "class_animal.html#a1b9feccff2783a6a13fefd8724532676", null ]
];