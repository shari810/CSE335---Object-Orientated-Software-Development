var files_dup =
[
    [ "Animal.cpp", "_animal_8cpp.html", null ],
    [ "Animal.h", "_animal_8h.html", [
      [ "Animal", "class_animal.html", "class_animal" ]
    ] ],
    [ "Chicken.cpp", "_chicken_8cpp.html", null ],
    [ "Chicken.h", "_chicken_8h.html", [
      [ "Chicken", "class_chicken.html", "class_chicken" ]
    ] ],
    [ "Cow.cpp", "_cow_8cpp.html", null ],
    [ "Cow.h", "_cow_8h.html", [
      [ "Cow", "class_cow.html", "class_cow" ]
    ] ],
    [ "Farm.cpp", "_farm_8cpp.html", null ],
    [ "Farm.h", "_farm_8h.html", [
      [ "Farm", "class_farm.html", "class_farm" ]
    ] ],
    [ "Goat.cpp", "_goat_8cpp.html", null ],
    [ "Goat.h", "_goat_8h.html", [
      [ "Goat", "class_goat.html", "class_goat" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];