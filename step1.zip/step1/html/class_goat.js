var class_goat =
[
    [ "Type", "class_goat.html#a924f2b4c48781507fcb2781022e8f24a", [
      [ "Nanny", "class_goat.html#a924f2b4c48781507fcb2781022e8f24aabf2e39def307c823bc4a28f8c1506d7c", null ],
      [ "Billy", "class_goat.html#a924f2b4c48781507fcb2781022e8f24aa5ca49fbfb5ba90d2927d7f85f07ad74d", null ],
      [ "Wether", "class_goat.html#a924f2b4c48781507fcb2781022e8f24aa0464bb45779cff35380d6dd6919ec3b6", null ],
      [ "maleKid", "class_goat.html#a924f2b4c48781507fcb2781022e8f24aa08df14749403b5f81897534a13a4cb63", null ],
      [ "femaleKid", "class_goat.html#a924f2b4c48781507fcb2781022e8f24aafdac455d00ebe3f158c7543494dc9039", null ]
    ] ],
    [ "DisplayAnimal", "class_goat.html#a2dcd8ed3bff3165d2a2bdbd331368e3f", null ],
    [ "IsFemale", "class_goat.html#a6c32c411a388f302f84bcc80e238fb62", null ],
    [ "ObtainGoatInformation", "class_goat.html#aac3d3ca1a3cb26ec72ec18687f8c09c4", null ],
    [ "mName", "class_goat.html#afaf005f8df4ff62eaaaf7d6bd6e363a8", null ],
    [ "mType", "class_goat.html#a33c4c514bbfba2d9fb1bfdc0f4c08b6a", null ]
];