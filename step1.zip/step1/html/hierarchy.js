var hierarchy =
[
    [ "Animal", "class_animal.html", [
      [ "Chicken", "class_chicken.html", null ],
      [ "Cow", "class_cow.html", null ],
      [ "Goat", "class_goat.html", null ]
    ] ],
    [ "Farm", "class_farm.html", null ]
];