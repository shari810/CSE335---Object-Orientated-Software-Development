var annotated_dup =
[
    [ "Animal", "class_animal.html", "class_animal" ],
    [ "Chicken", "class_chicken.html", "class_chicken" ],
    [ "Cow", "class_cow.html", "class_cow" ],
    [ "Farm", "class_farm.html", "class_farm" ],
    [ "Goat", "class_goat.html", "class_goat" ]
];