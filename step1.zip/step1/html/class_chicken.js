var class_chicken =
[
    [ "DisplayAnimal", "class_chicken.html#a9b1a08339fbe56821fb4528862bdfa7e", null ],
    [ "IsFemale", "class_chicken.html#afe16d4989d0b8243a2af234bd181388f", null ],
    [ "ObtainChickenInformation", "class_chicken.html#aba51fdb4a8e42474cf55f77bf21352a9", null ],
    [ "mId", "class_chicken.html#a9edde79663192e67b2be14d020dd69d5", null ]
];