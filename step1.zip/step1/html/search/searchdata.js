var indexSectionsWithContent =
{
  0: "acdfgimot~",
  1: "acfg",
  2: "acfgm",
  3: "adimot~",
  4: "m",
  5: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations"
};

