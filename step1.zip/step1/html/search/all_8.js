var searchData=
[
  ['totalfemales_0',['TotalFemales',['../class_farm.html#adea807c593db6cebc02e6ee2764e384b',1,'Farm']]],
  ['type_1',['Type',['../class_cow.html#a8c4921713b515e2723a80bdc7cfb6a88',1,'Cow::Type()'],['../class_goat.html#a924f2b4c48781507fcb2781022e8f24a',1,'Goat::Type()']]]
];
