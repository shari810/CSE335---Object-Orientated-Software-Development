var searchData=
[
  ['obtainchickeninformation_0',['ObtainChickenInformation',['../class_chicken.html#aba51fdb4a8e42474cf55f77bf21352a9',1,'Chicken']]],
  ['obtaincowinformation_1',['ObtainCowInformation',['../class_cow.html#af62471383d151fd32ca07cd4033838c2',1,'Cow']]],
  ['obtaingoatinformation_2',['ObtainGoatInformation',['../class_goat.html#aac3d3ca1a3cb26ec72ec18687f8c09c4',1,'Goat']]]
];
