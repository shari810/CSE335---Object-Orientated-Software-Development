var searchData=
[
  ['_7eanimal_0',['~Animal',['../class_animal.html#a476af25adde5f0dfa688129c8f86fa5c',1,'Animal']]],
  ['_7efarm_1',['~Farm',['../class_farm.html#a551fad409c44962866226b3eb4d4b518',1,'Farm']]]
];
